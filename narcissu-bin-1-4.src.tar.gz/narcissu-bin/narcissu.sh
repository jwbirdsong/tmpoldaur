#!/bin/sh
cd /opt/narcissu
exec ./onscripter "$@"
